[Student Name], [Student ID], [Set], [Date]

This assignment is [enter percent]% complete.


------------------------
Question one (PhoneNumbers) status:

[complete or not complete]
[explanation if not complete, what is working/not working]

------------------------
Question two (CylinderStats) status:

[complete or not complete]
[explanation if not complete, what is working/not working]

------------------------
Question three (Cylinder) status:

[complete or not complete]
[explanation if not complete, what is working/not working]

------------------------
Question four (Box) status:

[complete or not complete]
[explanation if not complete, what is working/not working]

------------------------
Question five (Email) status:

[complete or not complete]
[explanation if not complete, what is working/not working]
