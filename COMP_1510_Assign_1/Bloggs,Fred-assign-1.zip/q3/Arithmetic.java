package q3;
import java.util.Scanner;
/**
 * This program reads two floating point numbers from the
 * user, then finds the sum, difference, quotient, and
 * product of the numbers. 
 *
 * @author Scott Reid A0116009
 * @version 1.0
 */
public class Arithmetic {
    /**
     * This is the entry point that gets called to run the program. First it 
     * calls two methods, one that reads each floating point number from 
     * the user. Then, it passes in the numbers to four methods, 
     * one each for sum, difference, product, and quotient.
     *
     * @param args unused.
     */
    public static void main(String[] args) {
        float float1 = getFloat1();
        float float2 = getFloat2();

        float sum = sum(float1, float2);
        System.out.println("The sum is " + sum);

        float difference = difference(float1, float2);
        System.out.println("The difference is " + difference);

        float product = product(float1, float2);
        System.out.println("The product is " + product);

        if (float2 == 0) {
            System.out.println("The second floating point number is 0. "
                    + "You cannot divide by 0.");
        } else {
            float quotient = quotient(float1, float2);
            System.out.println("The quotient is " + quotient);
        }

        System.out.println("Question three was called and ran sucessfully.");
    }
    
    /**
     * This function asks the user for input.
     *
     * @param none
     * @return the first floating point number
     */
    public static float getFloat1() {
        Scanner secondsInput = new Scanner(System.in);
        System.out.println("Please enter a floating point number");

        float input1 = secondsInput.nextFloat();
        return input1;
    }
    /**
     * This function asks the user for input.
     *
     * @param none
     * @return the second floating point number
     */
    public static float getFloat2() {
        Scanner secondsInput = new Scanner(System.in);
        System.out.println("Please enter a second floating point number");

        float input2 = secondsInput.nextFloat();

        return input2;
    }
    /**
     * This function returns the sum of the numbers passed to it.
     *
     * @param float1 is the first number input by the user
     * @param float2 is the second number input by the user
     * @return the sum of the two numbers
     */
    public static float sum(float float1, float float2) {
        return float1 + float2;
    }
    /**
     * This function returns the difference of the numbers passed to it.
     *
     * @param float1 is the first number input by the user
     * @param float2 is the second number input by the user
     * @return the difference of the two numbers
     */
    public static float difference(float float1, float float2) {
        return float1 - float2;
    }
    /**
     * This function returns the product of the numbers passed to it.
     *
     * @param float1 is the first number input by the user
     * @param float2 is the second number input by the user
     * @return the product of the two numbers
     */
    public static float product(float float1, float float2) {
        return float1 * float2;
    }
    /**
     * This function returns the quotient of the numbers passed to it.
     *
     * @param float1 is the first number input by the user
     * @param float2 is the second number input by the user
     * @return the quotient of the two numbers
     */
    public static float quotient(float float1, float float2) {
        return float1 / float2;
    }

}
