package q2;
import java.util.Scanner;
/**
 * This program takes in a number of seconds from the user, divides 
 * it into hours, minutes, and seconds, and then formats the output
 * as a time in HH:MM:SS.
 *
 * @author Scott Reid A01160090
 * @version 1.0
 */
public class SecondsConvert {

    /**
     * This is the number of seconds in an hour.
     */
    public static final int SECONDS_HOUR = 3600;
    /**
     * This is the number of seconds in a minute.
     */
    public static final int SECONDS_MINUTE = 60;
    
    /**
     * This is the main method. It calls a function that prompts
     * the user for input, the calls functions that divide 
     * this input (in seconds) to hours, minutes, and seconds. 
     *
     * @param args unused.
     */
    
    public static void main(String[] args) {
        int seconds = getSeconds();
        int hours = getHours(seconds);
        int remainingSeconds = getRemainder(seconds, hours, 0);
        int minutes = getMinutes(remainingSeconds);
        remainingSeconds = getRemainder(seconds, hours, minutes);
        System.out.println(hours + ":" + minutes + ":" + remainingSeconds);
        System.out.println("Question two was called and ran sucessfully.");
        }
    /**
     * This function asks the user for input.
     *
     * @param none
     * @return the integer amount of seconds entered by the user. 
     */
    public static int getSeconds() {
        Scanner secondsInput = new Scanner(System.in);
        System.out.println("Please enter the number of seconds you" 
        + "want to convert to hh:mm:ss");

        int seconds = secondsInput.nextInt();
        return seconds;
        }
    /**
     * This function asks the user for input.
     *
     * @param seconds is the amount of seconds entered by the user.
     * @return the integer amount of hours that can fit in 
     * the number of seconds.
     */
    public static int getHours(int seconds) {
        int hours = seconds / SECONDS_HOUR;
        return hours;
        }
    /**
     * This function finds the remainder (in seconds) after the number
     * of hours or minutes that can fit into the number of seconds
     * provided by the user has been determined. 
     *
     * @param seconds is the number of seconds entered by the user
     * @param hours is the number of hours that can fit into the number
     * of seconds entered by the user
     * @param minutes is the number of minutes that can fit into 
     * the number of seconds entered by the user minus
     * the number of hours * 60.
     * @return the integer amount of seconds entered by the user. 
     */
    public static int getRemainder(int seconds, int hours, int minutes) {
        int remainingSeconds = seconds - (hours * SECONDS_HOUR 
                + minutes * SECONDS_MINUTE);
        return remainingSeconds;
        }
    /**
     * This function finds out the number of minutes that can fit into 
     * the number of seconds entered by the user minus
     * the number of hours * 60.
     *
     * @param remainingSeconds is the number of seconds remaining
     * from the user's initial input minus the number of hours
     * that can fir into the user's initial input * 3600.
     * @return the integer amount of minutes that can fit
     * in the remaining seconds. 
     */
    public static int getMinutes(int remainingSeconds) {
        int minutes = remainingSeconds / SECONDS_MINUTE;
        return minutes;
        }
        
    }

