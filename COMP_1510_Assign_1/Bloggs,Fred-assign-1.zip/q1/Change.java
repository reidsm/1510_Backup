package q1;
import java.util.Scanner;

/**
 * This program asks a user for a double amount, converts the amount to cents, 
 * and then divides up the cents into different denominations of 
 * bills and coins. 
 *
 * @author Scott Reid A01160090
 * @version 1.0
 */
public class Change {
    /**
     * The number of cents in a dollar.
     */
    public static final int HUNDRED = 100;
    /**
     * The number of cents in a $10 bill. 
     */
    public static final int TENDENOM = 1000;
    /**
     * The number of cents in a $5 bill. 
     */
    public static final int FIVEDENOM = 500;
    /**
     * The number of cents in a $2 bill. 
     */
    public static final int TWODENOM = 200;
    /**
     * The number of cents in a quarter. 
     */
    public static final int QUARTERDENOM = 25;
    /**
     * The number of cents in a dime. 
     */
    public static final int DIMEDENOM = 10;
    /**
     * The number of cents in a nickel. 
     */
    public static final int NICKELDENOM = 5;
    
    /**
     * This is the main method. It calls functions to ask the user for input,
     * convert the input to pennies, and then calls functions to find the 
     * maximum amount of bills or coins in each denomination that can fit
     * in the remaining amount of pennies.
     *
     * @param args unused.
     */
    public static void main(String[] args) {
        double amount = prompt();
        int numberOfPennies = convertToPennies(amount);
        int penniesRemaining = numberOfTens(numberOfPennies);
        penniesRemaining = numberOfFives(penniesRemaining);
        penniesRemaining = numberOfTwos(penniesRemaining);
        penniesRemaining = numberOfOnes(penniesRemaining);
        penniesRemaining = numberOfQuarters(penniesRemaining);
        penniesRemaining = numberOfDimes(penniesRemaining);
        penniesRemaining = numberOfNickels(penniesRemaining);
        System.out.println(penniesRemaining + " pennies");
        System.out.println("Question one was called and ran sucessfully.");
    }
    /**
     * This function asks the user for input.
     *
     * @param none
     * @return the double amount entered by the user. 
     */
    public static double prompt() {
        Scanner howMuch = new Scanner(System.in);
        System.out.println("Please enter a monetary amount:");

        double amount = howMuch.nextDouble();
        return amount;
    }
    
    /**
     * This function converts the dollar amount to a number of pennies. 
     *
     * @param amount is the double amount entered by the user.
     * @return the integer amount of pennies entered by the user. 
     */
    public static int convertToPennies(double amount) {
        double convertedAmount = amount * HUNDRED;
        int pennies = (int) convertedAmount;
        //System.out.println(pennies);
        return pennies;
    }
    /**
     * This function determines the maximum number of ten dollar bills 
     * that make up the user's amount.
     *
     * @param numberOfPennies is the user's amount converted to the number
     * of pennies
     * @return the double amount of pennies remaining after removing the number
     *  of tens split out * 1000 pennies (the denomination of a ten 
     *  dollar bill in pennies).
     */
    public static int numberOfTens(int numberOfPennies) {
        int numberOfTens = numberOfPennies / TENDENOM;
        System.out.println(numberOfTens + " ten dollar bills");
        int penniesRemaining = numberOfPennies - numberOfTens * TENDENOM;
        return penniesRemaining;
    }
    /**
     * This function determines the maximum number of five dollar bills 
     * that make up the user's amount.
     *
     * @param numberOfPennies is the user's amount converted to the number
     * of pennies
     * @return the double amount of pennies remaining after removing the number
     *  of fives split out * 500 pennies (the denomination of a five 
     *  dollar bill in pennies).
     */
    public static int numberOfFives(int numberOfPennies) {
        int numberOfFives = numberOfPennies / FIVEDENOM;
        System.out.println(numberOfFives + " five dollar bills");
        int penniesRemaining = numberOfPennies - numberOfFives * FIVEDENOM;
        return penniesRemaining;
    }
    /**
     * This function determines the maximum number of two dollar coins 
     * that make up the user's amount.
     *
     * @param numberOfPennies is the user's amount converted to the number
     * of pennies
     * @return the double amount of pennies remaining after removing the number
     *  of two dollar coins split out * 200 pennies (the denomination of a two 
     *  dollar coin in pennies).
     */
    public static int numberOfTwos(int numberOfPennies) {
        int numberOfTwos = numberOfPennies / TWODENOM;
        System.out.println(numberOfTwos + " toonies");
        int penniesRemaining = numberOfPennies - numberOfTwos * TWODENOM;
        return penniesRemaining;
    }
    /**
     * This function determines the maximum number of one dollar coins 
     * that make up the user's amount.
     *
     * @param numberOfPennies is the user's amount converted to the number
     * of pennies
     * @return the double amount of pennies remaining after removing the number
     *  of one dollar coins split out * 100 pennies (the denomination of a one 
     *  dollar coin in pennies).
     */
    public static int numberOfOnes(int numberOfPennies) {
        int numberOfOnes = numberOfPennies / HUNDRED;
        System.out.println(numberOfOnes + " loonies");
        int penniesRemaining = numberOfPennies - numberOfOnes * HUNDRED;
        return penniesRemaining;
    }
    /**
     * This function determines the maximum number of quarters 
     * that make up the user's amount.
     *
     * @param numberOfPennies is the user's amount converted to the number
     * of pennies
     * @return the double amount of pennies remaining after removing the number
     *  of quarters split out * 25 pennies (the denomination of a quarter 
     *  in pennies).
     */
    public static int numberOfQuarters(int numberOfPennies) {
        int numberOfQuarters = numberOfPennies / QUARTERDENOM;
        System.out.println(numberOfQuarters + " quarters");
        int penniesRemaining = numberOfPennies - numberOfQuarters 
                * QUARTERDENOM;
        return penniesRemaining;
    }
    /**
     * This function determines the maximum number of dimes 
     * that make up the user's amount.
     *
     * @param numberOfPennies is the user's amount converted to the number
     * of pennies
     * @return the double amount of pennies remaining after removing the number
     * of dimes split out * 10 pennies (the denomination of a dime
     * in pennies).
     */
    public static int numberOfDimes(int numberOfPennies) {
        int numberOfDimes = numberOfPennies / DIMEDENOM;
        System.out.println(numberOfDimes + " dimes");
        int penniesRemaining = numberOfPennies - numberOfDimes * DIMEDENOM;
        return penniesRemaining;
    }
    /**
     * This function determines the maximum number of nickels 
     * that make up the user's amount.
     *
     * @param numberOfPennies is the user's amount converted to the number
     * of pennies
     * @return the double amount of pennies remaining after removing the number
     *  of nickels split out * 5 pennies (the denomination of a 
     *  nickel in pennies).
     */
    public static int numberOfNickels(int numberOfPennies) {
        int numberOfNickels = numberOfPennies / NICKELDENOM;
        System.out.println(numberOfNickels + " nickels");
        int penniesRemaining = numberOfPennies - numberOfNickels * NICKELDENOM;
        return penniesRemaining;
    }
        
    }



