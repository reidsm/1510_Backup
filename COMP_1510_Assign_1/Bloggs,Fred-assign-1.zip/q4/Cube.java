package q4;
import java.util.Scanner;
/**
 * This program takes a number from a user that represents the 
 * side length of a cube and cubes it to find the area of a cube. 
 *
 * @author Scott Reid A0116009
 * @version 1.0
 */
public class Cube {
    
    /**
     * THis is the number of sides on a cube. 
     */
    public static final int CUBE_SIDES = 6;
    
    /**
     * This is the entry point that gets called to run the program.
     * It calls a method that gets the side length from the
     * user, then calls two methods, one for calculating volume
     * and one for calculating surface area. 
     *
     * @param args unused.
     */
    
    public static void main(String[] args) {
        int sideLength = getSideLength();
        int volume = volume(sideLength);
        int surfaceArea = surfaceArea(sideLength);
        System.out.println("The volume of this cube is " + volume);
        System.out.println("The surface area of this cube is " + surfaceArea);
        System.out.println("Question four was called and ran sucessfully.");
    }
    /**
     * This function asks the user for input.
     *
     * @param none
     * @return the side length from the user
     */
    public static int getSideLength() {
        Scanner secondsInput = new Scanner(System.in);
        System.out.println("Please enter an integer representing "
                + "the side length of a cube:");

        int input1 = secondsInput.nextInt();
        return input1;
    }
    /**
     * This function cubes the user input.
     *
     * @param sideLength was input by the user
     * @return the volume of the cube
     */
    public static int volume(int sideLength) {
        int volume = sideLength * sideLength * sideLength;
        return volume;
    }
    /**
     * This function calculates the surface area.
     *
     * @param sideLength was input from the user
     * @return the surface area of the cube
     */
    public static int surfaceArea(int sideLength) {
        int surfaceArea = (sideLength * sideLength) * CUBE_SIDES;
        return surfaceArea;
    }

}
