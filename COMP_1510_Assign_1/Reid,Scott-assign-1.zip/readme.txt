[Scott Reid], [A01160090], [Set D], [Sept. 18, 2019]

This assignment is [100]% complete.


------------------------
Question one (Change) status:

[complete]

------------------------
Question two (SecondsConvert) status:

[complete]

------------------------
Question three (Arithmetic) status:

[complete]

------------------------
Question four (Cube) status:

[complete]

------------------------
Question five (Pack) status:

[complete]
