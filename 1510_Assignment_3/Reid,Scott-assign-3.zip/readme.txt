[Scott Reid], [A01160090], [D], [November 6, 2019]

This assignment is [100]% complete.


------------------------
Question one (WordCounter) status:

[complete]

------------------------
Question two (Primes) status:

[complete]

------------------------
Question three (TestStudent and supporting classes) status:

[complete]

------------------------
Question four (TestCourse and supporting classes) status:

[complete]

------------------------
