[Scott Reid], [A01160090], [D], [Nov 27 2019]

This assignment is [100]% complete.


------------------------
Question one (Statistics) status:

[complete]

------------------------
Question two (DrawStar) status:

[complete]

------------------------
Question three (TestMIXChar) status:

[complete]
